const mongoose = require("mongoose");

const employeeSchema = new mongoose.Schema({
  passportData: {
    fullName: { type: String, required: true },
    inn: { type: String, required: true },
    insp: { type: String, required: true },
    address: { type: String, required: true },
    passportSeries: { type: String, required: true },
    passportNumber: { type: String, required: true },
    issuedBy: { type: String, required: true },
    issuedDate: { type: Date, required: true },
    birthDate: { type: Date, required: true },
    gender: { type: String, required: true },
    birthPlace: { type: String, required: true },
    nationality: { type: String, required: true },
    phoneNumber: { type: String, required: true },
  },
  jobData: {
    department: { type: String, required: true },
    position: { type: String, required: true },
    grade: { type: String, required: true },
    salary: { type: String, required: true },
    employmentContract: { type: String, required: true },
    hireDate: { type: Date, required: true },
    orderNumber: { type: String, required: true },
  },
  educationData: {
    educationLevel: { type: String, required: true },
    institution: { type: String, required: true },
    specialty: { type: String, required: true },
    graduationYear: { type: String, required: true },
    diplomaNumber: { type: String, required: true },
    academicTitle: { type: String, required: false },
  },
  vacationStatus: {
    type: String,
    enum: [
      "none",
      "mexnat tatili",
      "mexnatga layoqatsizlik davri",
      "ish xaqi saqlanmagan tatil",
      "o'quv tatili",
      "bir oylik xizmat",
    ],
    default: "none",
  },
  documents: [
    {
      fileName: { type: String, required: true },
      filePath: { type: String, required: true },
      uploadedAt: { type: Date, default: Date.now },
    },
  ],

});

// Virtual maydon: Ish Tajribasi
employeeSchema.virtual("jobData.experience").get(function () {
  if (!this.jobData || !this.jobData.hireDate) return "Ma'lumot mavjud emas";

  const hireDate = new Date(this.jobData.hireDate);
  const today = new Date();

  let years = today.getFullYear() - hireDate.getFullYear();
  let months = today.getMonth() - hireDate.getMonth();

  // Agar oylar salbiy bo'lsa, yillardan 1 yil olib tashlanadi
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  if (years === 0 && months === 0) return "0 oy";
  if (years === 0) return `${months} oy`;
  if (months === 0) return `${years} yil`;
  return `${years} yil va ${months} oy`;
});

// Virtual maydonlarni JSON va obyektga qo'shish
employeeSchema.set("toJSON", { virtuals: true });
employeeSchema.set("toObject", { virtuals: true });

module.exports = mongoose.model("Employee", employeeSchema);
