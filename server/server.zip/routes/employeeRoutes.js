const express = require("express");
const multer = require("multer");
const mongoose = require("mongoose");
const path = require("path");
const upload = require("../config/multerConfig"); // Yangi multer konfiguratsiyasi
const Employee = require("../models/Employee");
const router = express.Router();
const { addEmployee } = require("../controllers/employeeController");
const positionsByDepartment = require("../config/positionsByDeparment")

// Barcha xodimlarni olish
router.get("/", async (req, res) => {
  try {
    const employees = await Employee.find();
    res.status(200).json(employees);
  } catch (err) {
    console.error("Xodimlarni olishda xatolik:", err);
    res.status(500).json({ error: "Xodimlarni olishda xatolik!" });
  }
});

// ID bo'yicha xodimni olish
router.get("/:id", async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ error: "Xodim topilmadi!" });
    res.status(200).json(employee);
  } catch (err) {
    res.status(500).json({ error: "Server xatoligi" });
  }
});

// Xodimning ta'til holatini yangilash
router.put("/:id/vacation", async (req, res) => {
  try {
    const { vacationStatus } = req.body; // vacationStatus stringni qabul qiladi

    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ error: "Xodim topilmadi!" });
    }

    // Vacation statusni string sifatida yangilash
    employee.vacationStatus = vacationStatus;
    await employee.save();

    res.status(200).json({ vacationStatus: employee.vacationStatus });
  } catch (error) {
    console.error("Xatolik:", error);
    res.status(500).json({ error: "Server xatoligi yuz berdi!" });
  }
});

// Yangi xodim qo'shish
router.post("/", async (req, res) => {
  const { passportData, jobData, educationData } = req.body;

  if (!passportData || !jobData || !educationData) {
    return res.status(400).json({ error: "Barcha bo'limlar to'ldirilishi kerak!" });
  }

  const department = jobData.department;
  const position = jobData.position;

  // Bo'lim va lavozimni tekshirish
  const departmentData = positionsByDepartment[department];
  if (!departmentData) {
    return res.status(400).json({ error: "Noto'g'ri bo'lim tanlandi!" });
  }

  const positionData = departmentData.positions.find((pos) => pos.name === position);
  if (!positionData) {
    return res.status(400).json({ error: "Noto'g'ri lavozim tanlandi!" });
  }

  try {
    // Bo'lim bo'yicha umumiy cheklovni tekshirish
    const departmentCount = await Employee.countDocuments({
      "jobData.department": department,
    });
    if (departmentCount >= departmentData.maxEmployees) {
      return res.status(400).json({
        error: `Ushbu bo'lim uchun maksimal xodimlar soni (${departmentData.maxEmployees}) yetib bo'lgan!`,
      });
    }

    // Lavozim bo'yicha cheklovni tekshirish
    const positionCount = await Employee.countDocuments({
      "jobData.department": department,
      "jobData.position": position,
    });
    if (positionCount >= positionData.max) {
      return res.status(400).json({
        error: `Bu lavozim uchun maksimal xodimlar soni (${positionData.max}) yetib bo'lgan!`,
      });
    }

    // Yangi xodimni yaratish
    const newEmployee = new Employee({
      passportData,
      jobData,
      educationData,
      vacationStatus: "none",
    });

    const savedEmployee = await newEmployee.save();
    res.status(201).json(savedEmployee);
  } catch (err) {
    console.error("Xodimni qo'shishda xatolik:", err);
    res.status(500).json({ error: "Serverda xatolik yuz berdi!" });
  }
});

//xujjat yuklash
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Fayllar saqlanadigan joy
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`); // Fayl nomi
  },
});



// Hujjatlarni qo'shish uchun API
// Bir nechta fayl uchun: "documents" nomli maydon orqali
router.post("/documents/:id", upload.array("documents", 3), async (req, res) => {
  const employeeId = req.params.id;

  try {
    const employee = await Employee.findById(employeeId);
    if (!employee) {
      return res.status(404).json({ error: "Xodim topilmadi" });
    }

    // Yangi hujjatlarni qo'shish
    const newDocuments = req.files.map((file) => ({
      fileName: file.filename, // GridFS'dagi fayl nomi
      filePath: `/uploads/${file.filename}`,
      uploadedAt: new Date(),
    }));

    // Xodim hujjatlariga qo'shish
    employee.documents.push(...newDocuments);
    await employee.save();

    res.status(200).json({
      message: "Hujjatlar muvaffaqiyatli yuklandi!",
      documents: newDocuments,
    });
  } catch (error) {
    console.error("Hujjat yuklashda xatolik:", error);
    res.status(500).json({ error: "Serverda xatolik yuz berdi" });
  }
});
// Xodimni o'chirish
router.delete("/:id", async (req, res) => {
  try {
    const deletedEmployee = await Employee.findByIdAndDelete(req.params.id);
    if (!deletedEmployee) return res.status(404).json({ error: "Xodim topilmadi!" });
    res.status(200).json(deletedEmployee);
  } catch (err) {
    res.status(500).json({ error: "Xodimni o'chirishda xatolik!" });
  }
});

module.exports = router;
