const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");
const morgan = require("morgan"); // Loglar uchun middleware
const path = require("path"); // Fayl yo'llari bilan ishlash uchun
const { GridFsStorage } = require("multer-gridfs-storage"); // GridFS uchun
const multer = require("multer"); // Fayllarni yuklash uchun
const Grid = require("gridfs-stream"); // Fayllarni o'qish uchun
const employeeRoutes = require("./routes/employeeRoutes");
const Employee = require("./models/Employee");
const fs = require("fs");

dotenv.config(); // .env faylni o'qish

const app = express();
const PORT = process.env.PORT || 5000;

// Fayllar uchun yuklash katalogini yaratish
const uploadDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
  console.log(`"${uploadDir}" katalogi yaratildi.`);
}

// Middleware
const corsOptions = {
  origin: "http://localhost:3000", // Frontend URL
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"],
};
app.use(cors(corsOptions));
app.use(express.json());
app.use(morgan("dev")); // HTTP loglar
app.use("/uploads", express.static(uploadDir)); // Statik fayllarni xizmat qilish
app.use("/api/employees", employeeRoutes);

// MongoDB ulanish
// let gfs;
// mongoose.connection.once("open", () => {
//   gfs = new mongoose.mongo.GridFSBucket(mongoose.connection.db, {
//     bucketName: "documents", // Fayllarni saqlash uchun bucketName
//   });
//   console.log("GridFS initialized");
// });

// MongoDB ulanish sozlamalari
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, 'uploads');
    cb(null, uploadPath); // Fayllar 'uploads' papkasida saqlanadi
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName); // Fayl nomi noyob bo'ladi
  },
});

const upload = multer({ storage });
app.post('/api/employees/:id/documents', upload.array('files', 10), async (req, res) => {
  try {
    const { id } = req.params;
    const { names } = req.body;
    const files = req.files;

    if (!files || files.length === 0) {
      return res.status(400).json({ message: "No files uploaded." });
    }

    if (!Array.isArray(names) || names.length !== files.length) {
      return res.status(400).json({ message: "Document names must match the number of files." });
    }

    const employee = await Employee.findById(id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found." });
    }

    // Fayllar haqidagi ma'lumotlarni shakllantirish
    const documents = files.map((file, index) => ({
      fileName: names[index],
      filePath: `/uploads/${file.filename}`,
    }));

    // Validatsiya
    if (documents.some(doc => !doc.fileName || !doc.filePath)) {
      return res.status(400).json({ message: "Invalid fileName or filePath in documents." });
    }

    // Hujjatlarni saqlash
    employee.documents.push(...documents);
    await employee.save();

    res.status(200).json({ message: "Documents added successfully.", employee });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});



// Fayllarni yuklab olish API
app.get('/api/employees/:id/documents', async (req, res) => {
  try {
    const { id } = req.params;

    // Xodimni topish
    const employee = await Employee.findById(id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found." });
    }

    // Xodimga tegishli hujjatlarni qaytarish
    res.status(200).json({ documents: employee.documents });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

// Fayllarni o'chirish API
app.delete('/api/employees/:id/documents/:fileName', async (req, res) => {
  try {
    const { id, fileName } = req.params;

    // Xodimni topish
    const employee = await Employee.findById(id);
    if (!employee) {
      return res.status(404).json({ message: "Employee not found." });
    }

    // Faylni topib o'chirish
    const documentIndex = employee.documents.findIndex(doc => doc.fileName === fileName);
    if (documentIndex === -1) {
      return res.status(404).json({ message: "Document not found." });
    }

    // Faylni o'chirish
    const [removedDocument] = employee.documents.splice(documentIndex, 1);
    await employee.save();

    // Serverdagi faylni ham o'chirish (agar kerak bo'lsa)
    const fs = require('fs');
    const path = require('path');
    const filePath = path.join(__dirname, removedDocument.filePath);
    fs.unlink(filePath, (err) => {
      if (err) {
        console.error(`Failed to delete file: ${filePath}`);
      }
    });

    res.status(200).json({ message: "Document deleted successfully.", document: removedDocument });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
});

// Xodimlar API yo'llari
app.use("/api/employees", employeeRoutes);

// Serverni ishga tushirish
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// MongoDB ulanish
mongoose
  .connect(process.env.MONGO_URI || "mongodb://localhost:27017/employeeDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected successfully"))
  .catch((err) => console.log("MongoDB connection error: ", err));