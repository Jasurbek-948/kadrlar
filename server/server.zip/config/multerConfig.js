const multer = require("multer");
const { GridFsStorage } = require("multer-gridfs-storage");
const dotenv = require("dotenv");

dotenv.config(); // .env faylni o'qish

// MongoDB URL
const mongoURI = process.env.MONGO_URI || "mongodb://localhost:27017/employeeDB";

// GridFsStorage konfiguratsiyasi
const storage = new GridFsStorage({
  url: mongoURI,
  file: (req, file) => {
    return new Promise((resolve, reject) => {
      const filename = `${Date.now()}-${file.originalname}`; // Fayl nomi
      const fileInfo = {
        filename: filename,
        bucketName: "uploads", // Fayl saqlanadigan bucket (GridFS ichida 'uploads.files' va 'uploads.chunks' yaratiladi)
      };
      resolve(fileInfo);
    });
  },
});

// Multer yuklash konfiguratsiyasi
const upload = multer({ storage });

module.exports = upload;
