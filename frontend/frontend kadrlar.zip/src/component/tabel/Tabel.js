import React from 'react'

const Tabel = () => {
  return (
    <div>
       bu yerga tabel joylanadi
    </div>
  )
}

export default Tabel
