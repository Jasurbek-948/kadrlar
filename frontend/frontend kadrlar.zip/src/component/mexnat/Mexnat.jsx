import React from 'react'

const Mexnat = () => {
  return (
    <div>
      mexnat shartnomasi
    </div>
  )
}

export default Mexnat
