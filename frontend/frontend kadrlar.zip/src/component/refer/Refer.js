import React from 'react'

const Refer = () => {
  return (
    <div>
      <h1>Bu sahifa xozircha bo`sh</h1>
    </div>
  )
}

export default Refer
